<?php return array (
  'themes' => 
  array (
    'enabled' => true,
    'themes_path' => '/var/www/html/resources/themes',
    'asset_not_found' => 'LOG_ERROR',
    'active' => 'pterodactyl',
    'themes' => 
    array (
      'pterodactyl' => 
      array (
        'extends' => NULL,
        'views-path' => 'pterodactyl',
        'asset-path' => 'themes/pterodactyl',
      ),
    ),
  ),
  'recaptcha' => 
  array (
    'enabled' => true,
    'domain' => 'https://www.google.com/recaptcha/api/siteverify',
    'secret_key' => '6LekAxoUAAAAAPW-PxNWaCLH76WkClMLSa2jImwD',
    'website_key' => '6LekAxoUAAAAADjWZJ4ufcDRZBBiH9vfHawqRbup',
    'verify_domain' => true,
  ),
  'session' => 
  array (
    'driver' => 'database',
    'lifetime' => 10080,
    'expire_on_close' => false,
    'encrypt' => true,
    'files' => '/var/www/html/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'pterodactyl_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
  ),
  'laroute' => 
  array (
    'path' => 'public/js',
    'filename' => 'laroute',
    'namespace' => 'Router',
    'absolute' => false,
    'filter' => 'all',
    'action_namespace' => '',
    'template' => 'vendor/lord/laroute/src/templates/laroute.js',
    'prefix' => '',
  ),
  'prologue' => 
  array (
    'alerts' => 
    array (
      'levels' => 
      array (
        0 => 'info',
        1 => 'warning',
        2 => 'danger',
        3 => 'success',
      ),
      'session_key' => 'alert_messages',
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => NULL,
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => '/var/www/html/storage/debugbar',
      'connection' => NULL,
    ),
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'laravel' => false,
      'events' => true,
      'default_request' => false,
      'symfony_request' => true,
      'mail' => true,
      'logs' => false,
      'files' => false,
      'config' => false,
      'auth' => false,
      'gate' => false,
      'session' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => false,
      ),
      'db' => 
      array (
        'with_params' => true,
        'timeline' => true,
        'backtrace' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
            1 => 'INSERT',
            2 => 'UPDATE',
            3 => 'DELETE',
          ),
        ),
        'hints' => false,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'standard',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => NULL,
        'secret' => NULL,
        'prefix' => NULL,
        'queue' => 'standard',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'standard',
        'retry_after' => 90,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'mandrill' => 
    array (
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'Pterodactyl\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => 'games-db',
        'port' => '3306',
        'database' => 'pterodb',
        'username' => 'ptero',
        'password' => 'a6L1Gsdsd0V4RnwF',
        'charset' => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix' => '',
        'strict' => false,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => 'localhost',
        'password' => NULL,
        'port' => 6379,
        'database' => 0,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'null',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'pterodactyl' => 
  array (
    'service' => 
    array (
      'core' => 'ptrdctyl-v040-11e6-8b77-86f30ca893d3',
      'author' => 'admin',
    ),
    'auth' => 
    array (
      'notifications' => false,
    ),
    'paginate' => 
    array (
      'frontend' => 
      array (
        'servers' => 15,
      ),
      'api' => 
      array (
        'nodes' => 25,
        'servers' => 25,
        'users' => 25,
      ),
    ),
    'api' => 
    array (
      'include_on_list' => false,
    ),
    'guzzle' => 
    array (
      'timeout' => 5,
      'connect_timeout' => 3,
    ),
    'queues' => 
    array (
      'low' => 'low',
      'standard' => 'standard',
      'high' => 'high',
    ),
    'console' => 
    array (
      'count' => 10,
      'frequency' => 200,
    ),
    'tasks' => 
    array (
      'clear_log' => 720,
      'delete_server' => 10,
    ),
    'cdn' => 
    array (
      'cache' => 60,
      'url' => 'https://cdn.pterodactyl.io/releases/latest.json',
    ),
    'lang' => 
    array (
      'in_context' => false,
    ),
    'json_routes' => 
    array (
      0 => 'api/*',
      1 => 'daemon/*',
      2 => 'remote/*',
    ),
  ),
  'settings' => 
  array (
    'default' => 'database',
    'cache' => true,
    'encryption' => false,
    'events' => true,
    'repositories' => 
    array (
      'database' => 
      array (
        'driver' => 'database',
        'connection' => 'mysql',
        'table' => 'settings',
      ),
    ),
    'key_generator' => 'Krucas\\Settings\\KeyGenerators\\KeyGenerator',
    'context_serializer' => 'Krucas\\Settings\\ContextSerializers\\ContextSerializer',
    'value_serializer' => 'Krucas\\Settings\\ValueSerializers\\ValueSerializer',
    'override' => 
    array (
    ),
  ),
  'cache' => 
  array (
    'default' => 'memcached',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/var/www/html/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => 'cache',
            'port' => '11211',
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'laravel',
  ),
  'javascript' => 
  array (
    'bind_js_vars_to_this_view' => 
    array (
      0 => 'layouts.scripts',
    ),
    'js_namespace' => 'Pterodactyl',
  ),
  'laravel-fractal' => 
  array (
    'default_serializer' => 'League\\Fractal\\Serializer\\JsonApiSerializer',
  ),
  'app' => 
  array (
    'env' => 'production',
    'version' => '0.6.4',
    'name' => 'Pterodactyl',
    'debug' => false,
    'url' => 'https://panel.sfoxdev.com/',
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'key' => 'base64:n0K9bUaOn+NpuxQfuIuVf2dBNxGuldAfWtOXdJBfLJU=',
    'cipher' => 'AES-256-CBC',
    'log' => 'daily',
    'log_level' => 'debug',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      13 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      14 => 'Illuminate\\Queue\\QueueServiceProvider',
      15 => 'Illuminate\\Redis\\RedisServiceProvider',
      16 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      17 => 'Illuminate\\Session\\SessionServiceProvider',
      18 => 'Illuminate\\Validation\\ValidationServiceProvider',
      19 => 'Illuminate\\View\\ViewServiceProvider',
      20 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      21 => 'Laravel\\Tinker\\TinkerServiceProvider',
      22 => 'Pterodactyl\\Providers\\AppServiceProvider',
      23 => 'Pterodactyl\\Providers\\AuthServiceProvider',
      24 => 'Pterodactyl\\Providers\\EventServiceProvider',
      25 => 'Pterodactyl\\Providers\\RouteServiceProvider',
      26 => 'Pterodactyl\\Providers\\MacroServiceProvider',
      27 => 'Pterodactyl\\Providers\\PhraseAppTranslationProvider',
      28 => 'Barryvdh\\Debugbar\\ServiceProvider',
      29 => 'PragmaRX\\Google2FA\\Vendor\\Laravel\\ServiceProvider',
      30 => 'igaster\\laravelTheme\\themeServiceProvider',
      31 => 'Prologue\\Alerts\\AlertsServiceProvider',
      32 => 'Krucas\\Settings\\Providers\\SettingsServiceProvider',
      33 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
      34 => 'Laracasts\\Utilities\\JavaScript\\JavaScriptServiceProvider',
      35 => 'Lord\\Laroute\\LarouteServiceProvider',
      36 => 'Spatie\\Fractal\\FractalServiceProvider',
    ),
    'aliases' => 
    array (
      'Alert' => 'Prologue\\Alerts\\Facades\\Alert',
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Carbon' => 'Carbon\\Carbon',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Cron' => 'Cron\\CronExpression',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Fractal' => 'Spatie\\Fractal\\FractalFacade',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Google2FA' => 'PragmaRX\\Google2FA\\Vendor\\Laravel\\Facade',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Input' => 'Illuminate\\Support\\Facades\\Input',
      'Inspiring' => 'Illuminate\\Foundation\\Inspiring',
      'Javascript' => 'Laracasts\\Utilities\\JavaScript\\JavaScriptFacade',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Settings' => 'Krucas\\Settings\\Facades\\Settings',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Theme' => 'igaster\\laravelTheme\\Facades\\Theme',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Uuid' => 'Webpatser\\Uuid\\Uuid',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'Version' => 'Pterodactyl\\Facades\\Version',
      'View' => 'Illuminate\\Support\\Facades\\View',
    ),
  ),
  'mail' => 
  array (
    'driver' => 'mail',
    'host' => 'smtp.mailgun.org',
    'port' => 587,
    'from' => 
    array (
      'address' => 'admin@sfoxdev.com',
      'name' => 'Pterodactyl Panel',
    ),
    'encryption' => 'tls',
    'username' => NULL,
    'password' => NULL,
    'sendmail' => '/usr/sbin/sendmail -bs',
    'pretend' => false,
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/var/www/html/resources/views/vendor/mail',
      ),
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => 
    array (
      0 => '',
    ),
    'headers' => 
    array (
      2 => 'X_FORWARDED_FOR',
      4 => 'X_FORWARDED_HOST',
      8 => 'X_FORWARDED_PROTO',
      16 => 'X_FORWARDED_PORT',
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/storage/app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/storage/app/public',
        'url' => 'https://panel.sfoxdev.com//storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
      ),
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/var/www/html/resources/themes/pterodactyl',
      1 => '/var/www/html/resources/themes',
      2 => '/var/www/html/resources/views',
    ),
    'compiled' => '/data/storage/framework/views',
  ),
  'compile' => 
  array (
    'files' => 
    array (
    ),
    'providers' => 
    array (
    ),
  ),
);
