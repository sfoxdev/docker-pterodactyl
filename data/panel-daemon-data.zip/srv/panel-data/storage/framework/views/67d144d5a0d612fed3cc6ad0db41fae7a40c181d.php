<?php $__env->startSection('title'); ?>
    List Packs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1>Packs<small>All service packs available on the system.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li class="active">Packs</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Pack List</h3>
                <div class="box-tools">
                    <form action="<?php echo e(route('admin.packs')); ?>" method="GET">
                        <div class="input-group input-group-sm">
                            <input type="text" name="query" class="form-control pull-right" style="width:30%;" value="<?php echo e(request()->input('query')); ?>" placeholder="Search Packs">
                            <div class="input-group-btn">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                <a href="<?php echo e(route('admin.packs.new')); ?>"><button type="button" class="btn btn-sm btn-primary" style="border-radius: 0 3px 3px 0;margin-left:-1px;">Create New</button></a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th>ID</th>
                            <th>Pack Name</th>
                            <th>Version</th>
                            <th>Description</th>
                            <th>Option</td>
                            <th class="text-center">Servers</th>
                        </tr>
                        <?php $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="middle" data-toggle="tooltip" data-placement="right" title="<?php echo e($pack->uuid); ?>"><code><?php echo e($pack->id); ?></code></td>
                                <td class="middle"><a href="<?php echo e(route('admin.packs.view', $pack->id)); ?>"><?php echo e($pack->name); ?></a></td>
                                <td class="middle"><code><?php echo e($pack->version); ?></code></td>
                                <td class="col-md-6"><?php echo e(str_limit($pack->description, 150)); ?></td>
                                <td class="middle"><a href="<?php echo e(route('admin.services.option.view', $pack->option->id)); ?>"><?php echo e($pack->option->name); ?></a></td>
                                <td class="middle text-center"><?php echo e($pack->servers_count); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php if($packs->hasPages()): ?>
                <div class="box-footer with-border">
                    <div class="col-md-12 text-center"><?php echo $packs->render(); ?></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>