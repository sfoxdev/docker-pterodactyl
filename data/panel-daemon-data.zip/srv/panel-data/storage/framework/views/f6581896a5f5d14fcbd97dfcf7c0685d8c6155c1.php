<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="login-box-body">
    <?php if(count($errors) > 0): ?>
        <div class="callout callout-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo app('translator')->getFromJson('auth.auth_error'); ?><br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php $__currentLoopData = Alert::getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="callout callout-<?php echo e($type); ?> alert-dismissable" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo $message; ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p class="login-box-msg"><?php echo app('translator')->getFromJson('auth.authentication_required'); ?></p>
    <form id="loginForm" action="<?php echo e(route('auth.login')); ?>" method="POST">
        <div class="form-group has-feedback">
            <input name="user" class="form-control" value="<?php echo e(old('user')); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.user_identifier'); ?>">
            <span class="fa fa-envelope form-control-feedback"></span>
        </div>
        <div class="form-group has-feedback">
            <input type="password" name="password" class="form-control" placeholder="<?php echo app('translator')->getFromJson('strings.password'); ?>">
            <span class="fa fa-lock form-control-feedback"></span>
        </div>
        <div class="row">
            <div class="col-xs-8">
                <div class="form-group has-feedback">
                    <input type="checkbox" name="remember" id="remember" /> <label for="remember" class="weight-300"><?php echo app('translator')->getFromJson('auth.remember_me'); ?></label>
                </div>
            </div>
            <div class="col-xs-4">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-primary btn-block btn-flat g-recaptcha" <?php if(config('recaptcha.enabled')): ?> data-sitekey="<?php echo e(config('recaptcha.website_key')); ?>" data-callback='onSubmit' <?php endif; ?>><?php echo app('translator')->getFromJson('auth.sign_in'); ?></button>
            </div>
        </div>
    </form>
    <a href="<?php echo e(route('auth.password')); ?>"><?php echo app('translator')->getFromJson('auth.forgot_password'); ?></a><br>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php if(config('recaptcha.enabled')): ?>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <script>
        function onSubmit(token) {
            document.getElementById("loginForm").submit();
        }
        </script>
     <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>