<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.sftp.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.sftp.header'); ?><small><?php echo app('translator')->getFromJson('server.config.sftp.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.sftp_settings'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-6">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.sftp.change_pass'); ?></h3>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-sftp', $server)): ?>
                <form action="<?php echo e(route('server.settings.sftp', $server->uuidShort)); ?>" method="post">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="sftp_pass" class="control-label"><?php echo app('translator')->getFromJson('base.account.new_password'); ?></label>
                            <div>
                                <input type="password" class="form-control" name="sftp_pass" />
                                <p class="text-muted"><small><?php echo app('translator')->getFromJson('auth.password_requirements'); ?></small></p>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <?php echo csrf_field(); ?>

                        <input type="submit" class="btn btn-primary btn-sm" value="<?php echo app('translator')->getFromJson('base.account.update_pass'); ?>" />
                    </div>
                </form>
            <?php else: ?>
                <div class="box-body">
                    <div class="callout callout-warning callout-nomargin">
                        <p><?php echo app('translator')->getFromJson('auth.not_authorized'); ?></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.sftp.details'); ?></h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label"><?php echo app('translator')->getFromJson('server.config.sftp.conn_addr'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="sftp://<?php echo e($node->fqdn); ?>:<?php echo e($node->daemonSFTP); ?>" />
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="control-label"><?php echo app('translator')->getFromJson('strings.username'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="<?php echo e($server->username); ?>" />
                    </div>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-sftp-password', $server)): ?>
                    <div class="form-group">
                        <label for="password" class="control-label"><?php echo app('translator')->getFromJson('base.account.current_password'); ?></label>
                        <div>
                            <input type="text" class="form-control" readonly <?php if(! is_null($server->sftp_password)): ?>value="<?php echo e(Crypt::decrypt($server->sftp_password)); ?>"<?php endif; ?> />
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="box-footer">
                <p class="small text-muted"><?php echo app('translator')->getFromJson('server.config.sftp.warning'); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>