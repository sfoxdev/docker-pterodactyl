<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('base.security.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('base.security.header'); ?><small><?php echo app('translator')->getFromJson('base.security.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('account')); ?>"><?php echo app('translator')->getFromJson('strings.account'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('strings.security'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('base.security.sessions'); ?></h3>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('strings.id'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.ip'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.last_activity'); ?></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><code><?php echo e(substr($session->id, 0, 6)); ?></code></td>
                                <td><?php echo e($session->ip_address); ?></td>
                                <td><?php echo e(Carbon::createFromTimestamp($session->last_activity)->diffForHumans()); ?></td>
                                <td>
                                    <a href="<?php echo e(route('account.security.revoke', $session->id)); ?>">
                                        <button class="btn btn-xs btn-danger"><i class="fa fa-trash-o"></i> <?php echo app('translator')->getFromJson('strings.revoke'); ?></button>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="box <?php echo e((Auth::user()->use_totp) ? 'box-success' : 'box-danger'); ?>">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('base.security.2fa_header'); ?></h3>
            </div>
            <?php if(Auth::user()->use_totp): ?>
            <form action="<?php echo e(route('account.security.totp')); ?>" method="post">
                <div class="box-body">
                    <p><?php echo app('translator')->getFromJson('base.security.2fa_enabled'); ?></p>
                    <div class="form-group">
                        <label for="new_password_again" class="control-label"><?php echo app('translator')->getFromJson('strings.2fa_token'); ?></label>
                        <div>
                            <input type="text" class="form-control" name="token" />
                            <p class="text-muted small"><?php echo app('translator')->getFromJson('base.security.2fa_token_help'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger btn-sm"><?php echo app('translator')->getFromJson('base.security.disable_2fa'); ?></button>
                </div>
            </form>
            <?php else: ?>
            <form action="#" method="post" id="do_2fa">
                <div class="box-body">
                    <?php echo app('translator')->getFromJson('base.security.2fa_disabled'); ?>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-success btn-sm"><?php echo app('translator')->getFromJson('base.security.enable_2fa'); ?></button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="modal fade" id="open2fa" tabindex="-1" role="dialog" aria-labelledby="open2fa" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="#" method="post" id="2fa_token_verify">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo app('translator')->getFromJson('base.security.2fa_qr'); ?></h4>
                </div>
                <div class="modal-body" id="modal_insert_content">
                    <div class="row">
                        <div class="col-md-12" id="notice_box_2fa" style="display:none;"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <center><span id="hide_img_load"><i class="fa fa-spinner fa-spin"></i> Loading QR Code...</span><img src="" id="qr_image_insert" style="display:none;"/><br /><code id="2fa_secret_insert"></code></center>
                        </div>
                        <div class="col-md-6">
                            <div class="alert alert-info"><?php echo app('translator')->getFromJson('base.security.2fa_checkpoint_help'); ?></div>
                            <div class="form-group">
                                <label class="control-label" for="2fa_token"><?php echo app('translator')->getFromJson('strings.2fa_token'); ?></label>
                                <?php echo csrf_field(); ?>

                                <input class="form-control" type="text" name="2fa_token" id="2fa_token" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm" id="submit_action"><?php echo app('translator')->getFromJson('strings.submit'); ?></button>
                    <button type="button" class="btn btn-default btn-sm" data-dismiss="modal" id="close_reload"><?php echo app('translator')->getFromJson('strings.close'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/2fa-modal.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>