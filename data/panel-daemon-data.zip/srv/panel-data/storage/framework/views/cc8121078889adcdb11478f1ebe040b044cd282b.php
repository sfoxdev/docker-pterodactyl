<?php $__env->startSection('title'); ?>
    Services &rarr; <?php echo e($service->name); ?> &rarr; Functions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo e($service->name); ?><small>Extend the default daemon functions using this service file.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('admin.services')); ?>">Services</a></li>
        <li><a href="<?php echo e(route('admin.services.view', $service->id)); ?>"><?php echo e($service->name); ?></a></li>
        <li class="active">Functions</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li><a href="<?php echo e(route('admin.services.view', $service->id)); ?>">Overview</a></li>
                <li class="active"><a href="<?php echo e(route('admin.services.view.functions', $service->id)); ?>">Functions</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Functions Control</h3>
            </div>
            <form action="<?php echo e(route('admin.services.view', $service->id)); ?>" method="POST">
                <div class="box-body no-padding">
                    <div id="editor_index"style="height:500px"><?php echo e($service->index_file); ?></div>
                    <textarea name="index_file" class="hidden"></textarea>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="redirect_to" value="functions" />
                    <button type="submit" name="action" value="edit" class="btn btn-sm btn-success pull-right">Save File</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('vendor/ace/ace.js'); ?>

    <?php echo Theme::js('vendor/ace/ext-modelist.js'); ?>

    <script>
    $(document).ready(function () {
        const Editor = ace.edit('editor_index');
        const Modelist = ace.require('ace/ext/modelist')

        Editor.setTheme('ace/theme/chrome');
        Editor.getSession().setMode('ace/mode/javascript');
        Editor.getSession().setUseWrapMode(true);
        Editor.setShowPrintMargin(false);

        $('form').on('submit', function (e) {
            $('textarea[name="index_file"]').val(Editor.getValue());
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>