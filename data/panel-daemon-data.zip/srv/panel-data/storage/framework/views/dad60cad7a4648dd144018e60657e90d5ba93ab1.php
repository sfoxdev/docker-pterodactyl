<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.tasks.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.tasks.header'); ?><small><?php echo app('translator')->getFromJson('server.tasks.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.task_management'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.tasks.current'); ?></h3>
                <div class="box-tools">
                    <a href="<?php echo e(route('server.tasks.new', $server->uuidShort)); ?>"><button class="btn btn-primary btn-sm">Create New</button></a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('strings.action'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.data'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.queued'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.last_run'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.next_run'); ?></th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr <?php if(! $task->active): ?>class="muted muted-hover"<?php endif; ?>>
                                <td class="middle"><?php echo e($actions[$task->action]); ?></td>
                                <td class="middle"><code><?php echo e($task->data); ?></code></td>
                                <td class="middle">
                                    <?php if($task->queued): ?>
                                        <span class="label label-success"><?php echo app('translator')->getFromJson('strings.yes'); ?></span>
                                    <?php else: ?>
                                        <span class="label label-default"><?php echo app('translator')->getFromJson('strings.no'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="middle">
                                <?php if($task->last_run): ?>
                                    <?php echo e(Carbon::parse($task->last_run)->toDayDateTimeString()); ?><br /><span class="text-muted small">(<?php echo e(Carbon::parse($task->last_run)->diffForHumans()); ?>)</span>
                                <?php else: ?> 
                                    <?php echo app('translator')->getFromJson('strings.not_run_yet'); ?>
                                <?php endif; ?>
                                </td>
                                <td class="middle">
                                    <?php if($task->active !== 0): ?>
                                        <?php echo e(Carbon::parse($task->next_run)->toDayDateTimeString()); ?><br /><span class="text-muted small">(<?php echo e(Carbon::parse($task->next_run)->diffForHumans()); ?>)</span>
                                    <?php else: ?>
                                        <em>n/a</em>
                                    <?php endif; ?>
                                </td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-task', $server)): ?>
                                    <td class="text-center middle"><a href="#" data-action="delete-task" data-id="<?php echo e($task->id); ?>"><i class="fa fa-fw fa-trash-o text-danger" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('strings.delete'); ?>"></i></a></td>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('toggle-task', $server)): ?>
                                    <td class="text-center middle"><a href="#" data-action="toggle-task" data-active="<?php echo e($task->active); ?>" data-id="<?php echo e($task->id); ?>"><i class="fa fa-fw fa-eye-slash text-primary" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('server.tasks.toggle'); ?>"></i></a></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <?php echo Theme::js('js/frontend/tasks.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>