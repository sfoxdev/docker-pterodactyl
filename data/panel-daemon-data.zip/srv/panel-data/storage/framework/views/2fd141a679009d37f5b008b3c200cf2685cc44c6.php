<?php $__env->startSection('title'); ?>
    Packs &rarr; New
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1>New Pack<small>Create a new pack on the system.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('admin.packs')); ?>">Packs</a></li>
        <li class="active">New</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li class="active"><a href="<?php echo e(route('admin.packs.new')); ?>">Configure Manually</a></li>
                <li><a href="#modal" id="toggleModal">Install From Template</a></li>
            </ul>
        </div>
    </div>
</div>
<form action="<?php echo e(route('admin.packs.new')); ?>" method="POST" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Pack Details</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="pName" class="form-label">Name</label>
                        <input name="name" type="text" id="pName" class="form-control" value="<?php echo e(old('name')); ?>" />
                        <p class="text-muted small">A short but descriptive name of what this pack is. For example, <code>Counter Strike: Source</code> if it is a Counter Strike package.</p>
                    </div>
                    <div class="form-group">
                        <label for="pDescription" class="form-label">Description</label>
                        <textarea name="description" id="pDescription" class="form-control" rows="8"><?php echo e(old('description')); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="pVersion" class="form-label">Version</label>
                        <input type="text" name="version" id="pVersion" class="form-control" value="<?php echo e(old('version')); ?>" />
                        <p class="text-muted small">The version of this package, or the version of the files contained within the package.</p>
                    </div>
                    <div class="form-group">
                        <label for="pOptionId" class="form-label">Associated Option</label>
                        <select id="pOptionId" name="option_id" class="form-control">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <optgroup label="<?php echo e($service->name); ?>">
                                    <?php $__currentLoopData = $service->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option->id); ?>"><?php echo e($option->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="text-muted small">The option that this pack is assocaited with. Only servers that are assigned this option will be able to access this pack.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Pack Configuration</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input id="pSelectable" name="selectable" type="checkbox" value="1" checked/>
                            <label for="pSelectable">
                                Selectable
                            </label>
                        </div>
                        <p class="text-muted small">Check this box if user should be able to select this pack to install on their servers.</p>
                    </div>
                    <div class="form-group">
                        <div class="checkbox checkbox-primary no-margin-bottom">
                            <input id="pVisible" name="visible" type="checkbox" value="1" checked/>
                            <label for="pVisible">
                                Visible
                            </label>
                        </div>
                        <p class="text-muted small">Check this box if this pack is visible in the dropdown menu. If this pack is assigned to a server it will be visible regardless of this setting.</p>
                    </div>
                    <div class="form-group">
                        <div class="checkbox checkbox-warning no-margin-bottom">
                            <input id="pLocked" name="locked" type="checkbox" value="1"/>
                            <label for="pLocked">
                                Locked
                            </label>
                        </div>
                        <p class="text-muted small">Check this box if servers assigned this pack should not be able to switch to a different pack.</p>
                    </div>
                    <hr />
                    <div class="form-group no-margin-bottom">
                        <label for="pFileUpload" class="form-label">Pack Archive</label>
                        <input type="file" accept=".tar.gz, application/gzip" name="file_upload" class="well well-sm" style="width:100%"/>
                        <p class="text-muted small">This package file must be a <code>.tar.gz</code> archive of pack files to be decompressed into the server folder.</p>
                        <p class="text-muted small">If your file is larger than <code>50MB</code> it is recommended to upload it using SFTP. Once you have added this pack to the system, a path will be provided where you should upload the file.</p>
                        <div class="callout callout-info callout-slim no-margin-bottom">
                            <p class="text-muted small"><strong>This server is currently configured with the following limits:</strong><br /><code>upload_max_filesize=<?php echo e(ini_get('upload_max_filesize')); ?></code><br /><code>post_max_size=<?php echo e(ini_get('post_max_size')); ?></code><br /><br />If your file is larger than either of those values this request will fail.</p>
                        </div>
                    </div>
                </div>
                <div class="box-footer with-border">
                    <?php echo csrf_field(); ?>

                    <button class="btn btn-sm btn-success pull-right" type="submit">Create Pack</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <script>
        $('#pOptionId').select2();
        $('#toggleModal').on('click', function (event) {
            event.preventDefault();

            $.ajax({
                method: 'GET',
                url: Router.route('admin.packs.new.template'),
                headers: { 'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content') },
            }).fail(function (jqXhr) {
                console.error(jqXhr);
                alert('There was an error trying to create the upload modal.');
            }).success(function (data) {
                $(data).modal();
                $('#pOptionIdModal').select2();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>