<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('base.errors.404.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- This is why we don't let Pterodactyl's make links... fat fingered dinosaurs... -->
<div class="row">
    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
        <div class="box box-warning">
            <div class="box-body text-center">
                <h1 class="text-yellow" style="font-size: 160px !important;font-weight: 100 !important;">404</h1>
                <p class="text-muted"><?php echo app('translator')->getFromJson('base.errors.404.desc'); ?></p>
            </div>
            <div class="box-footer with-border">
                <a href="<?php echo e(URL::previous()); ?>"><button class="btn btn-warning">&larr; <?php echo app('translator')->getFromJson('base.errors.return'); ?></button></a>
                <a href="/"><button class="btn btn-default"><?php echo app('translator')->getFromJson('base.errors.home'); ?></button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>