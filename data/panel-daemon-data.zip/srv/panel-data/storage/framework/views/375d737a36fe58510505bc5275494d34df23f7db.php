<?php $__env->startSection('title'); ?>
    Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1>Services<small>All services currently available on this system.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li class="active">Services</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Configured Services</h3>
                <div class="box-tools">
                    <a href="<?php echo e(route('admin.services.new')); ?>"><button class="btn btn-primary btn-sm">Create New</button></a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th class="text-center">Options</th>
                        <th class="text-center">Packs</th>
                        <th class="text-center">Servers</th>
                    </tr>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="middle"><a href="<?php echo e(route('admin.services.view', $service->id)); ?>"><?php echo e($service->name); ?></a></td>
                            <td class="col-xs-6 middle"><?php echo e($service->description); ?></td>
                            <td class="text-center middle"><code><?php echo e($service->options_count); ?></code></td>
                            <td class="text-center middle"><code><?php echo e($service->packs_count); ?></code></td>
                            <td class="text-center middle"><code><?php echo e($service->servers_count); ?></code></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>