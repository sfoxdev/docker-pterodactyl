<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.users.new.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.users.new.header'); ?><small><?php echo app('translator')->getFromJson('server.users.new.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><a href="<?php echo e(route('server.subusers', $server->uuidShort)); ?>"><?php echo app('translator')->getFromJson('navigation.server.subusers'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('server.users.add'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $oldInput = array_flip(is_array(old('permissions')) ? old('permissions') : []) ?>
<form action="<?php echo e(route('server.subusers.new', $server->uuidShort)); ?>" method="POST">
    <div class="row">
        <div class="col-sm-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="form-group">
                        <label class="control-label"><?php echo app('translator')->getFromJson('server.users.new.email'); ?></label>
                        <div>
                            <?php echo csrf_field(); ?>

                            <input type="email" class="form-control" name="email" />
                            <p class="text-muted small"><?php echo app('translator')->getFromJson('server.users.new.email_help'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="box-body">
                    <div class="btn-group pull-left">
                        <a id="selectAllCheckboxes" class="btn btn-sm btn-default"><?php echo app('translator')->getFromJson('strings.select_all'); ?></a>
                        <a id="unselectAllCheckboxes" class="btn btn-sm btn-default"><?php echo app('translator')->getFromJson('strings.select_none'); ?></a>
                    </div>
                    <input type="submit" name="submit" value="<?php echo app('translator')->getFromJson('server.users.add'); ?>" class="pull-right btn btn-sm btn-primary" />
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo app('translator')->getFromJson('server.users.new.' . $block . '_header'); ?></h3>
                    </div>
                    <div class="box-body">
                        <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission => $daemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group">
                                <div class="checkbox checkbox-primary no-margin-bottom">
                                    <input id="<?php echo e($permission); ?>" name="permissions[]" type="checkbox" value="<?php echo e($permission); ?>"/>
                                    <label for="<?php echo e($permission); ?>" class="strong">
                                        <?php echo app('translator')->getFromJson('server.users.new.' . str_replace('-', '_', $permission) . '.title'); ?>
                                    </label>
                                </div>
                                <p class="text-muted small"><?php echo app('translator')->getFromJson('server.users.new.' . str_replace('-', '_', $permission) . '.description'); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php if($loop->iteration % 2 === 0): ?>
                <div class="clearfix visible-lg-block visible-md-block visible-sm-block"></div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#selectAllCheckboxes').on('click', function () {
                $('input[type=checkbox]').prop('checked', true);
            });
            $('#unselectAllCheckboxes').on('click', function () {
                $('input[type=checkbox]').prop('checked', false);
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>