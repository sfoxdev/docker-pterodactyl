<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.files.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.files.header'); ?><small><?php echo app('translator')->getFromJson('server.files.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.file_management'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.file_browser'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="overlay file-overlay"><i class="fa fa-refresh fa-spin"></i></div>
            <div id="load_files">
                <div class="box-body table-responsive no-padding">
                    <div class="callout callout-info" style="margin:10px;"><?php echo app('translator')->getFromJson('server.files.loading'); ?></div>
                </div>
            </div>
            <div class="box-footer with-border">
                <p class="text-muted small" style="margin: 0 0 2px;"><?php echo app('translator')->getFromJson('server.files.path', ['path' => '<code>/home/container</code>', 'size' => '<code>' . $node->upload_size . ' MB</code>']); ?></p>
            </div>
        </div>
    <div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <?php echo Theme::js('vendor/async/async.min.js'); ?>

    <?php echo Theme::js('vendor/lodash/lodash.js'); ?>

    <?php echo Theme::js('vendor/siofu/client.min.js'); ?>

    <?php if(App::environment('production')): ?>
        <?php echo Theme::js('js/frontend/files/filemanager.min.js'); ?>

    <?php else: ?>
        <?php echo Theme::js('js/frontend/files/src/index.js'); ?>

        <?php echo Theme::js('js/frontend/files/src/contextmenu.js'); ?>

        <?php echo Theme::js('js/frontend/files/src/actions.js'); ?>

    <?php endif; ?>
    <?php echo Theme::js('js/frontend/files/upload.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>