<?php $__env->startSection('title'); ?>
    Services &rarr; New Option
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1>New Option<small>Create a new service option to assign to servers.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('admin.services')); ?>">Services</a></li>
        <li class="active">New Service Option</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.services.option.new')); ?>" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Configuration</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="pServiceId" class="form-label">Associated Service</label>
                                <select name="service_id" id="pServiceId">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->id); ?>" <?php echo e(old('service_id') != $service->id ?: 'selected'); ?>><?php echo e($service->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="pName" class="form-label">Option Name</label>
                                <input type="text" id="pName" name="name" value="<?php echo e(old('name')); ?>" class="form-control" />
                                <p class="text-muted small">A simple, human-readable name to use as an identifier for this service.</p>
                            </div>
                            <div class="form-group">
                                <label for="pDescription" class="form-label">Description</label>
                                <textarea id="pDescription" name="description" class="form-control" rows="8"><?php echo e(old('description')); ?></textarea>
                                <p class="text-muted small">A description of this service that will be displayed throughout the panel as needed.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="pTag" class="form-label">Option Tag</label>
                                <input type="text" id="pTag" name="tag" value="<?php echo e(old('tag')); ?>" class="form-control" />
                                <p class="text-muted small">This should be a unique identifer for this service option that is not used for any other service options. Must be alpha-numeric and no more than 60 characters in length.</p>
                            </div>
                            <div class="form-group">
                                <label for="pDockerImage" class="form-label">Docker Image</label>
                                <input type="text" id="pDockerImage" name="docker_image" value="<?php echo e(old('docker_image')); ?>" placeholder="quay.io/pterodactyl/service" class="form-control" />
                                <p class="text-muted small">The default docker image that should be used for new servers under this service option. This can be left blank to use the parent service's defined image, and can also be changed per-server.</p>
                            </div>
                            <div class="form-group">
                                <label for="pStartup" class="form-label">Startup Command</label>
                                <textarea id="pStartup" name="startup" class="form-control" rows="4"><?php echo e(old('startup')); ?></textarea>
                                <p class="text-muted small">The default statup command that should be used for new servers under this service option. This can be left blank to use the parent service's startup, and can also be changed per-server.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Process Management</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="alert alert-warning">
                                <p>All fields are required unless you select a seperate option from the 'Copy Settings From' dropdown, in which case fields may be left blank to use the values from that option.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="pConfigFrom" class="form-label">Copy Settings From</label>
                                <select name="config_from" id="pConfigFrom" class="form-control">
                                    <option value="0">None</option>
                                </select>
                                <p class="text-muted small">If you would like to default to settings from another option select the option from the menu above.</p>
                            </div>
                            <div class="form-group">
                                <label for="pConfigStop" class="form-label">Stop Command</label>
                                <input type="text" id="pConfigStop" name="config_stop" class="form-control" value="<?php echo e(old('config_stop')); ?>" />
                                <p class="text-muted small">The command that should be sent to server processes to stop them gracefully. If you need to send a <code>SIGINT</code> you should enter <code>^C</code> here.</p>
                            </div>
                            <div class="form-group">
                                <label for="pConfigLogs" class="form-label">Log Configuration</label>
                                <textarea data-action="handle-tabs" id="pConfigLogs" name="config_logs" class="form-control" rows="6"><?php echo e(old('config_logs')); ?></textarea>
                                <p class="text-muted small">This should be a JSON representation of where log files are stored, and wether or not the daemon should be creating custom logs.</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="pConfigFiles" class="form-label">Configuration Files</label>
                                <textarea data-action="handle-tabs" id="pConfigFiles" name="config_files" class="form-control" rows="6"><?php echo e(old('config_files')); ?></textarea>
                                <p class="text-muted small">This should be a JSON representation of configuration files to modify and what parts should be changed.</p>
                            </div>
                            <div class="form-group">
                                <label for="pConfigStartup" class="form-label">Start Configuration</label>
                                <textarea data-action="handle-tabs" id="pConfigStartup" name="config_startup" class="form-control" rows="6"><?php echo e(old('config_startup')); ?></textarea>
                                <p class="text-muted small">This should be a JSON representation of what values the daemon should be looking for when booting a server to determine completion.</p>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-success btn-sm pull-right">Create Service</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('vendor/lodash/lodash.js'); ?>

    <script>
    $(document).ready(function() {
        $('#pServiceId').select2().change();
        $('#pConfigFrom').select2();
    });
    $('#pServiceId').on('change', function (event) {
        $('#pConfigFrom').html('<option value="0">None</option>').select2({
            data: $.map(_.get(Pterodactyl.services, $(this).val() + '.options', []), function (item) {
                return {
                    id: item.id,
                    text: item.name,
                };
            }),
        });
    });
    $('textarea[data-action="handle-tabs"]').on('keydown', function(event) {
        if (event.keyCode === 9) {
            event.preventDefault();

            var curPos = $(this)[0].selectionStart;
            var prepend = $(this).val().substr(0, curPos);
            var append = $(this).val().substr(curPos);

            $(this).val(prepend + '    ' + append);
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>