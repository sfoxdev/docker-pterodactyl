<?php $__env->startSection('title'); ?>
    Services &rarr; <?php echo e($service->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo e($service->name); ?><small><?php echo e(str_limit($service->description, 50)); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('admin.services')); ?>">Services</a></li>
        <li class="active"><?php echo e($service->name); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li class="active"><a href="<?php echo e(route('admin.services.view', $service->id)); ?>">Overview</a></li>
                <li><a href="<?php echo e(route('admin.services.view.functions', $service->id)); ?>">Functions</a></li>
            </ul>
        </div>
    </div>
</div>
<form action="<?php echo e(route('admin.services.view', $service->id)); ?>" method="POST">
    <div class="row">
        <div class="col-md-6">
            <div class="box">
                <div class="box-body">
                    <div class="form-group">
                        <label class="control-label">Name</label>
                        <div>
                            <input type="text" name="name" class="form-control" value="<?php echo e($service->name); ?>" />
                            <p class="text-muted"><small>This should be a descriptive category name that emcompasses all of the options within the service.</small></p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <div>
                            <textarea name="description" class="form-control" rows="6"><?php echo e($service->description); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box">
                <div class="box-body">
                    <div class="form-group">
                        <label class="control-label">Folder Name</label>
                        <div>
                            <input type="text" name="folder" class="form-control" value="<?php echo e($service->folder); ?>" />
                            <p class="text-muted"><small>Services are downloaded by the daemon and stored in a folder using this name. The storage location is <code>/srv/daemon/services/{NAME}</code> by default.</small></p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Default Start Command</label>
                        <div>
                            <textarea name="startup" class="form-control" rows="2"><?php echo e($service->startup); ?></textarea>
                            <p class="text-muted"><small>The default start command to use when running options under this service. This command can be modified per-option and should include the executable to be called in the container.</small></p>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <button id="deleteButton" type="input" name="action" value="delete" class="btn btn-sm btn-danger muted muted-hover"><i class="fa fa-trash-o"></i></button>
                    <button type="input" class="btn btn-primary btn-sm pull-right">Edit Service</button>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Configured Options</h3>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tr>
                        <th class="col-sm-4 col-md-3">Name</th>
                        <th>Description</th>
                        <th>Tag</th>
                        <th class="text-center">Servers</th>
                    </tr>
                    <?php $__currentLoopData = $service->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('admin.services.option.view', $option->id)); ?>"><?php echo e($option->name); ?></a></td>
                            <td><?php echo $option->description; ?></td>
                            <td><code><?php echo e($option->tag); ?></code></td>
                            <td class="text-center"><?php echo e($option->servers->count()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="box-footer">
                <a href="<?php echo e(route('admin.services.option.new')); ?>"><button class="btn btn-success btn-sm pull-right">New Service Option</button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <script>
        $('#deleteButton').on('mouseenter', function (event) {
            $(this).find('i').html(' Delete Service');
        }).on('mouseleave', function (event) {
            $(this).find('i').html('');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>