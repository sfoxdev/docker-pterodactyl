<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.database.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.database.header'); ?><small><?php echo app('translator')->getFromJson('server.config.database.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.databases'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.database.your_dbs'); ?></h3>
            </div>
            <?php if(count($databases) > 0): ?>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <th><?php echo app('translator')->getFromJson('strings.database'); ?></th>
                                <th><?php echo app('translator')->getFromJson('strings.username'); ?></th>
                                <th><?php echo app('translator')->getFromJson('strings.password'); ?></th>
                                <th><?php echo app('translator')->getFromJson('server.config.database.host'); ?></th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?><td></td><?php endif; ?>
                            </tr>
                            <?php $__currentLoopData = $databases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $database): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="middle"><?php echo e($database->database); ?></td>
                                    <td class="middle"><?php echo e($database->username); ?></td>
                                    <td class="middle"><code data-attr="set-password"><?php echo e(Crypt::decrypt($database->password)); ?></code></td>
                                    <td class="middle"><code><?php echo e($database->host->host); ?>:<?php echo e($database->host->port); ?></code></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?>
                                        <td>
                                            <button class="btn btn-xs btn-primary pull-right" data-action="reset-password" data-id="<?php echo e($database->id); ?>"><i class="fa fa-fw fa-refresh"></i> <?php echo app('translator')->getFromJson('server.config.database.reset_password'); ?></button>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="box-body">
                    <div class="callout callout-info callout-nomargin">
                        <?php echo app('translator')->getFromJson('server.config.database.no_dbs'); ?>
                        <?php if(Auth::user()->root_admin === 1): ?>
                            <a href="<?php echo e(route('admin.servers.view', [
                                'id' => $server->id,
                                'tab' => 'tab_database'
                            ])); ?>" target="_blank"><?php echo app('translator')->getFromJson('server.config.database.add_db'); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <script>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?>
        $('[data-action="reset-password"]').click(function (e) {
            e.preventDefault();
            var block = $(this);
            $(this).addClass('disabled').find('i').addClass('fa-spin');
            $.ajax({
                type: 'POST',
                url: Router.route('server.ajax.reset-database-password', { server: Pterodactyl.server.uuidShort }),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                },
                data: {
                    database: $(this).data('id')
                }
            }).done(function (data) {
                block.parent().parent().find('[data-attr="set-password"]').html(data);
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.error(jqXHR);
                var error = 'An error occured while trying to process this request.';
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                    error = jqXHR.responseJSON.error;
                }
                swal({
                    type: 'error',
                    title: 'Whoops!',
                    text: error
                });
            }).always(function () {
                block.removeClass('disabled').find('i').removeClass('fa-spin');
            });
        });
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>