


















<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo e(Settings::get('company', 'Pterodactyl')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#367fa9">

        <?php echo $__env->make('layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->startSection('scripts'); ?>
            <?php echo Theme::css('vendor/select2/select2.min.css'); ?>

            <?php echo Theme::css('vendor/bootstrap/bootstrap.min.css'); ?>

            <?php echo Theme::css('vendor/adminlte/admin.min.css'); ?>

            <?php echo Theme::css('vendor/adminlte/colors/skin-blue.min.css'); ?>

            <?php echo Theme::css('vendor/sweetalert/sweetalert.min.css'); ?>

            <?php echo Theme::css('vendor/animate/animate.min.css'); ?>

            <?php echo Theme::css('css/pterodactyl.css'); ?>

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        <?php echo $__env->yieldSection(); ?>
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="<?php echo e(route('index')); ?>" class="logo">
                    <span><?php echo e(Settings::get('company', 'Pterodactyl')); ?></span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="dropdown user-menu">
                                <a href="<?php echo e(route('account')); ?>" class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="https://www.gravatar.com/avatar/<?php echo e(md5(strtolower(Auth::user()->email))); ?>?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs"><?php echo e(Auth::user()->name_first); ?> <?php echo e(Auth::user()->name_last); ?></span>
                                </a>
                            </li>
                            <li>
                                <li><a href="<?php echo e(route('index')); ?>" data-toggle="tooltip" data-placement="bottom" title="Exit Admin Control"><i class="fa fa-server"></i></a></li>
                            </li>
                            <li>
                                <li><a href="<?php echo e(route('auth.logout')); ?>" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-power-off"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li class="header">BASIC ADMINISTRATION</li>
                        <li class="<?php echo e(Route::currentRouteName() !== 'admin.index' ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.index')); ?>">
                                <i class="fa fa-home"></i> <span>Overview</span>
                            </a>
                        </li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.settings') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.settings')); ?>">
                                <i class="fa fa-wrench"></i> <span>Settings</span>
                            </a>
                        </li>
                        <li class="header">MANAGEMENT</li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.databases') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.databases')); ?>">
                                <i class="fa fa-database"></i> <span>Databases</span>
                            </a>
                        </li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.locations') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.locations')); ?>">
                                <i class="fa fa-globe"></i> <span>Locations</span>
                            </a>
                        </li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.nodes') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.nodes')); ?>">
                                <i class="fa fa-sitemap"></i> <span>Nodes</span>
                            </a>
                        </li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.servers') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.servers')); ?>">
                                <i class="fa fa-server"></i> <span>Servers</span>
                            </a>
                        </li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.users')); ?>">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
                        <li class="header">SERVICE MANAGEMENT</li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.services') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.services')); ?>">
                                <i class="fa fa-th-large"></i> <span>Services</span>
                            </a>
                        </li>
                        <li class="<?php echo e(! starts_with(Route::currentRouteName(), 'admin.packs') ?: 'active'); ?>">
                            <a href="<?php echo e(route('admin.packs')); ?>">
                                <i class="fa fa-archive"></i> <span>Packs</span>
                            </a>
                        </li>
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    <?php echo $__env->yieldContent('content-header'); ?>
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            <?php if(count($errors) > 0): ?>
                                <div class="callout callout-danger">
                                    <?php echo app('translator')->getFromJson('base.validation_error'); ?><br><br>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php $__currentLoopData = Alert::getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="callout callout-<?php echo e($type); ?> alert-dismissable" role="alert">
                                        <?php echo $message; ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw <?php echo e($appIsGit ? 'fa-git-square' : 'fa-code-fork'); ?>"></i></strong> <?php echo e($appVersion); ?><br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> <?php echo e(round(microtime(true) - LARAVEL_START, 3)); ?>s
                </div>
                Copyright &copy; 2015 - <?php echo e(date('Y')); ?> <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
            </footer>
        </div>
        <?php $__env->startSection('footer-scripts'); ?>
            <?php echo Theme::js('js/keyboard.polyfill.js'); ?>

            <script>keyboardeventKeyPolyfill.polyfill();</script>

            <?php echo Theme::js('js/laroute.js'); ?>

            <?php echo Theme::js('vendor/jquery/jquery.min.js'); ?>

            <?php echo Theme::js('vendor/sweetalert/sweetalert.min.js'); ?>

            <?php echo Theme::js('vendor/bootstrap/bootstrap.min.js'); ?>

            <?php echo Theme::js('vendor/slimscroll/jquery.slimscroll.min.js'); ?>

            <?php echo Theme::js('vendor/adminlte/app.min.js'); ?>

            <?php echo Theme::js('vendor/socketio/socket.io.v203.min.js'); ?>

            <?php echo Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js'); ?>

            <?php echo Theme::js('vendor/select2/select2.full.min.js'); ?>

            <?php echo Theme::js('js/admin/functions.js'); ?>

            <?php echo Theme::js('js/autocomplete.js'); ?>


            <?php if(Auth::user()->isRootAdmin()): ?>
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();
                        if (confirm('Are you sure you want to logout?')) {
                            window.location = $(this).attr('href');
                        }
                    });
                </script>
            <?php endif; ?>
        <?php echo $__env->yieldSection(); ?>
    </body>
</html>
