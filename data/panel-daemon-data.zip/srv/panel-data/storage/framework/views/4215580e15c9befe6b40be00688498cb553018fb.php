<?php $__env->startSection('title'); ?>
    Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1>Panel Settings<small>Configure Pterodactyl to your liking.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Panel Settings</h3>
            </div>
            <form action="<?php echo e(route('admin.settings')); ?>" method="POST">
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label class="control-label">Company Name:</label>
                            <div>
                                <input type="text" class="form-control" name="company" value="<?php echo e(old('company', Settings::get('company'))); ?>" />
                                <p class="text-muted"><small>This is the name that is used throughout the panel and in emails sent to clients.</small></p>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-info">In order to modify your SMTP settings for sending mail you will need to run <code>php artisan pterodactyl:mail</code> in this project's root folder.</div>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <input type="submit" class="btn btn-sm btn-primary" value="Modify Settings">
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>