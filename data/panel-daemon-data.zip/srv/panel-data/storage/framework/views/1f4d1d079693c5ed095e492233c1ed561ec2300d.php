<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.allocation.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.allocation.header'); ?><small><?php echo app('translator')->getFromJson('server.config.allocation.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.port_allocations'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-8">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.allocation.available'); ?></h3>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('strings.ip'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.alias'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.port'); ?></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $server->allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <code><?php echo e($allocation->ip); ?></code>
                                </td>
                                <td class="middle">
                                    <?php if(is_null($allocation->ip_alias)): ?>
                                        <span class="label label-default"><?php echo app('translator')->getFromJson('strings.none'); ?></span>
                                    <?php else: ?>
                                        <code><?php echo e($allocation->ip_alias); ?></code>
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($allocation->port); ?></code></td>
                                <td class="col-xs-2 middle">
                                    <?php if($allocation->id === $server->allocation_id): ?>
                                        <span class="label label-success" data-allocation="<?php echo e($allocation->id); ?>"><?php echo app('translator')->getFromJson('strings.primary'); ?></span>
                                    <?php else: ?>
                                        <span class="label label-default" data-action="set-connection" data-allocation="<?php echo e($allocation->id); ?>"><?php echo app('translator')->getFromJson('strings.make_primary'); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.allocation.help'); ?></h3>
            </div>
            <div class="box-body">
                <p><?php echo app('translator')->getFromJson('server.config.allocation.help_text'); ?></p>
            </div>
        </div>
    <div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <script>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reset-db-password', $server)): ?>
        $('[data-action="reset-database-password"]').click(function (e) {
            e.preventDefault();
            var block = $(this);
            $(this).find('i').addClass('fa-spin');
            $.ajax({
                type: 'POST',
                url: Router.route('server.ajax.reset-database-password', { server: Pterodactyl.server.uuidShort }),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content'),
                },
                data: {
                    'database': $(this).data('id')
                }
            }).done(function (data) {
                block.parent().find('code').html(data);
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.error(jqXHR);
                var error = 'An error occured while trying to process this request.';
                if (typeof jqXHR.responseJSON !== 'undefined' && typeof jqXHR.responseJSON.error !== 'undefined') {
                    error = jqXHR.responseJSON.error;
                }
                swal({
                    type: 'error',
                    title: 'Whoops!',
                    text: error
                });
            }).always(function () {
                block.find('i').removeClass('fa-spin');
            });
        });
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>