<?php $__env->startSection('title'); ?>
    Services &rarr; Option: <?php echo e($option->name); ?> &rarr; Scripts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo e($option->name); ?><small>Manage install and upgrade scripts for this service option.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li><a href="<?php echo e(route('admin.services')); ?>">Services</a></li>
        <li><a href="<?php echo e(route('admin.services.view', $option->service->id)); ?>"><?php echo e($option->service->name); ?></a></li>
        <li class="active"><?php echo e($option->name); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li><a href="<?php echo e(route('admin.services.option.view', $option->id)); ?>">Configuration</a></li>
                <li><a href="<?php echo e(route('admin.services.option.variables', $option->id)); ?>">Variables</a></li>
                <li class="active"><a href="<?php echo e(route('admin.services.option.scripts', $option->id)); ?>">Scripts</a></li>
            </ul>
        </div>
    </div>
</div>
<form action="<?php echo e(route('admin.services.option.scripts', $option->id)); ?>" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Install Script</h3>
                </div>
                <?php if(! is_null($option->copyFrom)): ?>
                    <div class="box-body">
                        <div class="callout callout-warning no-margin">
                            This service option is copying installation scripts and containe options from <a href="<?php echo e(route('admin.services.option.view', $option->copyFrom->id)); ?>"><?php echo e($option->copyFrom->name); ?></a>. Any changes you make to this script will not apply unless you select "None" from the dropdown box below.
                        </div>
                    </div>
                <?php endif; ?>
                <div class="box-body no-padding">
                    <div id="editor_install"style="height:300px"><?php echo e($option->script_install); ?></div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-sm-4">
                            <label class="control-label">Copy Script From</label>
                            <select id="pCopyScriptFrom" name="copy_script_from">
                                <option value="0">None</option>
                                <?php $__currentLoopData = $copyFromOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($opt->id); ?>" <?php echo e($option->copy_script_from !== $opt->id ?: 'selected'); ?>><?php echo e($opt->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p class="text-muted small">If selected, script above will be ignored and script from selected option will be used in place.</p>
                        </div>
                        <div class="form-group col-sm-4">
                            <label class="control-label">Script Container</label>
                            <input type="text" name="script_container" class="form-control" value="<?php echo e($option->script_container); ?>" />
                            <p class="text-muted small">Docker container to use when running this script for the server.</p>
                        </div>
                        <div class="form-group col-sm-4">
                            <label class="control-label">Script Entrypoint Command</label>
                            <input type="text" name="script_entry" class="form-control" value="<?php echo e($option->script_entry); ?>" />
                            <p class="text-muted small">The entrypoint command to use for this script.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 text-muted">
                            The following service options rely on this script:
                            <?php if(count($relyOnScript) > 0): ?>
                                <?php $__currentLoopData = $relyOnScript; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rely): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('admin.services.option.view', $rely->id)); ?>">
                                        <code><?php echo e($rely->name); ?></code>&nbsp;
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <em>none</em>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <?php echo csrf_field(); ?>

                    <textarea name="script_install" class="hidden"></textarea>
                    <button type="submit" class="btn btn-primary btn-sm pull-right">Save Script</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('vendor/ace/ace.js'); ?>

    <?php echo Theme::js('vendor/ace/ext-modelist.js'); ?>

    <script>
    $(document).ready(function () {
        $('#pCopyScriptFrom').select2();

        const InstallEditor = ace.edit('editor_install');
        const Modelist = ace.require('ace/ext/modelist')

        InstallEditor.setTheme('ace/theme/chrome');
        InstallEditor.getSession().setMode('ace/mode/sh');
        InstallEditor.getSession().setUseWrapMode(true);
        InstallEditor.setShowPrintMargin(false);

        $('form').on('submit', function (e) {
            $('textarea[name="script_install"]').val(InstallEditor.getValue());
        });
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>